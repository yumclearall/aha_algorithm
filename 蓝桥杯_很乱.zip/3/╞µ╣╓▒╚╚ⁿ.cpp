#include <stdio.h>
int a[11]={0};
void dfs(int i,int score)
{
	int step;
	if(score==100&&i==11)
	{
		for(int b=1;b<=10;b++)
			printf("%d",a[b]);
		printf("\n");
	}
	if(score>153||score<=0||i>11) 
		return ;
	dfs(i+1,score-i);
	a[i]=1;
	dfs(i+1,score*2);
	a[i]=0;
}
int main()
{
	dfs(1,10);
	getchar();getchar();
	return 0;
}
