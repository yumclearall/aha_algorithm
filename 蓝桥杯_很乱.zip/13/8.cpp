#include <iostream>
#include <cstdio>
using namespace std;
int map[1004][1004],ss;
void boom(int x,int y,int r){
	for(int i = max(x - r,0); i < max(x + r,1004);i++){
		for (int j = max(x - r,0); j < max(x + r,1004);j++){
			if(map[i][j]!=0){
				ss++;
				int ff =map[i][j];
				map[i][j]=0;
				boom(i,j,ff);
			
			}
		}
	}
}
int main(){
	int n,m,a,b,c;
	scanf("%d%d",&n,&m);
	for(int i = 0; i < n; i++){
		scanf("%d%d%d",&a,&b,&c);
		map[a][b] = c;
	}
	for(int i = 0; i < m; i++){
		scanf("%d%d%d",&a,&b,&c);
		boom(a,b,c);
	}
	printf("%d\n",ss);
	return 0;
}
