#include <stdio.h>
int a[16],book[16],sum,tour;
int f1[16],f2[16];
void dfs(int b,int step)
{
	if(step==13&&b==2&&tour==5)
		{
			sum++;
			return;
		}
	else if(step>13||tour>5||b>14||b<=0)
		return;
		dfs(b-1,step+1);
		tour++;
		dfs(b*2,step+1);
		tour--;
		return;
}
int main()
{
	dfs(2,0);
	printf("%2d",sum);
	getchar();getchar();
	return 0;
}
