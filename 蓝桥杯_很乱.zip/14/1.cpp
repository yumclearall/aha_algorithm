#include <iostream>
#include <stdio.h>
using namespace std;
int main(){
	int mouth[13] = {0,31,28,31,30,31,30,31,31,30,31,30,31};
	int year = 1949, mou = 10, day = 1;
	int res = 0;
	while(true){
		if ((year%4==0 && year%100!=0) && year%400==0)
			mouth[2] = 29;
		else
			mouth[2] = 28;
		day++;
		res++;
		if (day > mouth[mou]){
			mou++;
			day = 1;
		}
		if (mou > 12){
			year++;
			mou = 1;
		}
		if (year == 2022 && mou == 1 && day == 1)
		//if (year == 1949 && mou == 11 && day == 2)
			break;
		
	}
	cout << res;
	return res;
} 

