#include <iostream>
#include <stdio.h>
#include <vector>
using namespace std;
int jud(vector<vector<char> > vc, int x, int y, int a, int b){
	int i = 1;
	while(i)
		if (	x-i>=0 && y-i>=0 && vc[x-i][y-i] == vc[x][y] &&
				x+i< a && y-i>=0 && vc[x+i][y-i] == vc[x][y] &&
				x-i>=0 && y+i< b && vc[x-i][y+i] == vc[x][y] &&
				x+i< a && y+i< b && vc[x+i][y+i] == vc[x][y]	)
				i++;
		else 
			break;
	return i - 1;
}
int main(){
	int a,b;
	int res = 0;
	cin >>a >>b;
	vector<vector<char> > vc(a,vector<char>(b));
	for (int i = 0; i < a; i++)
		for (int j = 0; j < b; j++)
			cin >> vc[i][j];
	for (int i = 0; i < a; i++){
		for (int j = 0; j < b; j++){
			res += jud(vc,i,j,a,b);
		}
	}
	cout << res;
	return 0;
}


