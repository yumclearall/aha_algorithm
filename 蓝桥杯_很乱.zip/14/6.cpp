#include <iostream>
#include <stdio.h>
#include <set>
#include <vector>
using namespace std;
int main(){
	int i;
	cin >> i;
	set<string> st;
	vector<string> vc;
	for (int j = 0; j < i; j++){
		string s;
		cin >> s;
		if (st.count(s))
			continue;
		else{
			st.insert(s);
			vc.push_back(s);
		}
	}
	int k = vc.size();
	for (int j = 0; j < k; j++)
		cout << vc[j] << endl;
	return 0;
}


