#include <stdio.h>
int main()
{
	int x=10,y=89;
	for(int i=1;i<=120;i++)
	{
		if(i%2==1)	y-=x;
		if(i%4==0) y*=2;
		if(i%6==0) x*=2;
		
	}
	if(y<0) y=0;
	printf("%d",y);
	getchar();getchar();
	return 0;
} 
