#include <stdio.h>
int n,m;
bool jud(long long x){
	if (x % n == 0 && x % m == 0){
		return true;
	}
	return false;
}
void dfs(long long x,long long cnt){
	if (cnt > 19 || x < 0){
		return;
	}
	if (jud(x)){
		printf("%d\n",x);
		return;
	}
	dfs(x * 10,cnt + 1);
	dfs(x * 10 + 1, cnt + 1);
}
int main(){
	scanf("%d%d",&n,&m);
	dfs(1,0);
	return 0;
}
