#include <stdio.h>
char mg[10][15] = {"***#G#***","*#*#..*.*","#..###..F",".###..##.","*O.#..#.*"};
int s[40],dir[4][2] = {{0,1},{-1,0},{0,-1},{1,0}};
char ss[5] = {'s','z','x','y','t'}; 
void dfs(int x,int y,int bx,int by,int step,int jud){
	if(step > 33)
		return;
	if(x == 0 && y == 4){
		if (step == 33 && jud == 1)
			for (int i = 0; i < 33; i++){
				if (s[i] < 4)
					printf("%c",ss[s[i]]);
				else
					printf("%c	%c",ss[s[i] - 4],ss[4]);
			printf("\n");
		}
		return;
	}
	int tx,ty,tz;
	for (int i = 0; i < 4; i++){
		tx = x; ty = y;	bx = x;	by = y; 
		tx += dir[i][0];
		ty += dir[i][1]; 
		if (tx == bx && ty == by)
			continue;
		if (tx < 0 || tx > 4 || ty < 0 || ty > 8 || mg[tx][ty] == '*' )
			continue;
		if (mg[tx][ty] == '#'){
			if (mg[tx + dir[i][0]][ty + dir[i][1]] == '.' ){
				mg[tx + dir[i][0]][ty + dir[i][1]] = '#';
				mg[tx][ty] = '.';
				s[step] = i + 4;
				dfs(x,y,x,y,step + 1,jud);
				mg[tx + dir[i][0]][ty + dir[i][1]] = '.';
				mg[tx][ty] = '#';
				s[step] = 0;
			}else
				continue;
		}
		if (mg[tx][ty] == 'F'){
			s[step] = i;
			dfs(tx,ty,bx,by,step + 1,jud + 1);
			s[step] = 0;
		}
		if (mg[tx][ty] == '.'){
			s[step] = i;
			dfs(tx,ty,bx,by,step + 1,jud);
			s[step] = 0;
		}
	}
	
}
int main(){
//	for (int i = 0; i < 5; i++){
//		for (int j = 0; j < 9; j++){
//			printf("%4c",mg[i][j]);
//		}
//		printf("\n");
//	}
	dfs(4,1,0,0,0,0);
	return 0;
} 
