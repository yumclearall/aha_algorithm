#include <stdio.h>
int main()
{
	for(int a=20;a>0;a--)
		for(int b=a;b>0;b--)
			for(int c=b;c>0;c--)
				for(int d=c;d>0;d--)
					{
						if((b*c*d + a*c*d + a*b*d+ b*c*a)==(a*b*c*d)&&a>b&&b>c&&c>d)
							printf("%d %d %d %d\n",a,b,c,d);}
	getchar();getchar();
		return 0;
}
