#include <stdio.h>
int end;
void dfs(int i,int num,int fu)
{
	if(num==0&&i%2) 
		end=1;
	if(num<0||i>fu)
		return;	
	dfs(i+1,num-1,fu);
	dfs(i+1,num-3,fu);
	dfs(i+1,num-7,fu);
	dfs(i+1,num-8,fu);
}
int main()
{
	int a,b[100],c;
	scanf("%d",&a);
	for(int i=1;i<=a;i++)
	{
		end=0;		
		scanf("%d",&c);
		dfs(1,c,c);
		b[i]=end;	
	}
	for(int i=1;i<=a;i++)
		printf("%d\n",b[i]);
	getchar();getchar();
	return 0;
}
