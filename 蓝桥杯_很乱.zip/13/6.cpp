#include <stdio.h>
int ss[105][105];
int main(){
	int sum = 0,ff,n,m;
	scanf("%d%d%d",&n,&m,&ff);
	for(int i = 0; i < n; i++){
		for(int j = 0; j < m; j++){
			scanf("%d",&ss[i][j]);
		}
	}
	for (int i = 0; i < n; i++){
		for (int j = i; j < n; j++){
			for (int  a = 0; a < m; a++){
				for (int b = a; b < m; b++){
					int k = 0;
						for(int c = i;c <= j; c++){
							if (k > sum)	break;
							for (int d = a; d <= b; d++){
								k += ss[c][d];
							}
						}
					if(k <= ff)	sum++;
					}
				}
			}
		}
	printf("%d\n",sum);
	return 0;
}
