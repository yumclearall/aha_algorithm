#include <stdio.h>
#include <stdlib.h>
struct Intp{
	char data;
	struct Intp *next;
}*head,*p,*q,*t,*f;
int main(){
	char n;
	head=NULL;q=head;
	while(1)	{		
		scanf("%c",&n);
		if(n=='$')	break;
		p=(struct Intp *)malloc(sizeof(struct Intp));
		p->data=n;
		p->next=q;
		q=p;	}
	printf("����:"); 
	t=q;
	while(t!=NULL)	{
		printf("%c",t->data);	
		t=t->next;}	
	getchar();getchar();
	return 0; } 
