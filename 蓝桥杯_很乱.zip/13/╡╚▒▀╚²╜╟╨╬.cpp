#include <stdio.h>
int n,sum;
int a[105];
bool f,book[105];
void dfs(int num,int cnt){
	if (f){
		return;
	}
	if (cnt == 3){
		f = true;
		return;
	}
	if (num == sum / 3){
		dfs(0,cnt + 1);
	}
	if (cnt > 3 || num > sum / 3){
		return;
	}
	for (int i = 0; i < n; i++){
		if (!book[i]){
			book[i] = true;
			dfs(num + a[i],cnt);
			book[i] = false;
		}
	}
}
int main(){
	scanf("%d",&n);
	for (int i = 0;i < n; i++){
		scanf("%d",&a[i]);
		sum += a[i];
	}
	if (sum % 3){
		printf("no\n");
		return 0;
	}
	dfs(0,0);
	if(f){
		printf("yes\n");
	}else{
		printf("no\n");
	}
	return 0;
}
