#include <iostream>
using namespace std;
bool book[11];
int f2[11],f1[11] = {0,1,2,3,4,5,6,7,8,9};
int n,sum;
int num(int x,int y){
	int m = 0;
	for(int i = y; i < x + y; i++){
		m *= 10;
		m += f2[i];
	}
	return m;
}
void dfs(int x){
	if (x == 10){
		for (int i = 1; i <= 7; i++){
			int d,b,c;
			d = num(i,1);
			if (d > n)
				continue;
			for(int j = i + 1; j <= 8; j++){
				b = num(j - i,i + 1);
				c = num(9 - j,j + 1);
				if (b < c || b % c != 0)
					continue;
				if(d + b / c == n){
				printf("%d %d %d\n",d,b,c);
				sum++;
				}}
				}
		return;
	}
	
	for (int i = 1; i < 10; i++)
	{
		if (!book[i]){
			book[i] = true;
			f2[x] = f1[i];
			dfs(x + 1);
			book[i] = false;
			f2[x] = 0;
		}
	}
}
int main(){
	cin >> n;
	dfs(1);
	printf("%d",sum);
	return 0;
}
