#include <iostream>
#include <cstdio>
using namespace std;
int a[100005],b[100005],c[100005];
long long int change(int x,int y,int n){
	if (x == 0)	return 0;
	long long int bb = 1;
	while(n-- > 0){
		bb = (bb % 1000000007) * y %  1000000007; 
	}
	return x * bb %  1000000007;
};
int main(){
	int n,ma,mb;
	long long int A = 0,B = 0;
	cin >> n;
	cin >> ma;
	for (int i = ma; i >= 1; i--){
		cin >> a[i];
	}
	cin >> mb;
	for (int i = mb; i >= 1; i--){
		cin >> b[i];
	}
	int mma = ma,mmb = mb;
	for (int i = 1; i <= ma; i++){
		c[i] = max(a[i],b[i]) + 1;
		if (c[i] == 1){
			c[i] = 2;
		}
	}
	for (int i = 1; i <= ma; i++){
		A += change(a[i],c[i],i - 1);
	}
	for (int i = 1; i <= mb; i++){
		B += change(b[i],c[i],i - 1);
	}
	printf("%d\n",A % 1000000007 - B % 1000000007);
	return 0;
}
