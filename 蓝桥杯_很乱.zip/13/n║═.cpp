#include <stdio.h>
int ans,a[10005];
bool book[1005];
int n,k,m;
void dfs(int x,int cnt,int sum){
	if (x == n){
		if (sum == m && cnt == k){
			ans++;
		}
		return;
	}
	if (sum > m){
		return;
	}
	dfs(x + 1,cnt + 1,sum + a[x]);
	dfs(x + 1,cnt,sum);
} 
int main(){
	scanf("%d%d%d",&n,&m,&k);
	for (int i = 0; i < n; i++){
		a[i] = i + 1;
	}
	dfs(0,0,0);
	printf("%d\n",ans);
	return 0;
} 
