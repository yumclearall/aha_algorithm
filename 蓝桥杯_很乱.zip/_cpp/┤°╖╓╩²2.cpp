#include <cstdio>
int a[11],sum;
int num(int x,int y){
	int m = 0;
	for(int i = y; i < x + y; i++){
		m *= 10;
		m += a[i];
	}
	return m;
}
int main(){
	int n;
	scanf("%d",&n);
	for(a[1] = 1; a[1] <= 9; a[1]++){
		for(a[2] = 1; a[2] <= 9; a[2]++){
			if (a[1] != a[2])
			for(a[3] = 1; a[3] <= 9; a[3]++){
				if (a[1] != a[3] && a[2] != a[3])
				for(a[4] = 1; a[4] <= 9; a[4]++){
					if (a[1] != a[4] && a[2] != a[4] && a[3] != a[4])
					for(a[5] = 1; a[5] <= 9; a[5]++){
						if (a[1] != a[5] && a[2] != a[5] && a[3] != a[5] && a[4] != a[5])
						for(a[6] = 1; a[6] < 9; a[6]++){
							if (a[1] != a[6] && a[2] != a[6] && a[3] != a[6] && a[4] != a[6] && a[5] != a[6])
							for(a[7] = 1; a[7] <= 9; a[7]++){
								if (a[1] != a[7] && a[2] != a[7] && a[3] != a[7] && a[4] != a[7] && a[5] != a[7] && a[6] != a[7])
								for(a[8] = 1; a[8] <= 9; a[8]++){
									if (a[1] != a[8] && a[2] != a[8] && a[3] != a[8] && a[4] != a[8] && a[5] != a[8] && a[6] != a[8] && a[7] != a[8])
									for(a[9] = 1; a[9] <= 9; a[9]++){
										if (a[1] != a[9] && a[2] != a[9] && a[3] != a[9] && a[4] != a[9] && a[5] != a[9] && a[6] != a[9] && a[7] != a[9] && a[8] != a[9]){
											
											for (int i = 1; i <= 7; i++){
												int d,b,c;
												d = num(i,1);
												if (d > n)
													continue;
												for(int j = i + 1; j <= 8; j++){
													b = num(j - i,i + 1);
													c = num(9 - j,j + 1);
													if (b < c || b % c != 0)
														continue;
													if(d + b / c == n){
														printf("%d %d %d\n",d,b,c);
														sum++;
													}
												}
											}
										}	
									}
								}
							}
						}
					}
				}
			}
		}
	}
	printf("%d\n",sum);
	return 0;
}
