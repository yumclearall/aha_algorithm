#include <iostream>//3 0 3 4 6 2 5 5 4 3
using namespace std;
int p[10][10],q[10][10]; 
int main(){
	int n;
	cin >> n;
	for (int i = 1; i <= n; i++){
		for (int j = 1; j <= n; j++){
			cin >> p[i][j];
		}
	}
	for (int i = 1; i <= n; i++){
		for (int j = 1; j <= n; j++){
			if (i == 1 && j ==1){
				continue;
			}
			else if (i == 1){
				q[i][j] = p[i][j] + q[i][j - 1];
			}
			else if (j == 1){
				q[i][j] += p[i][j] + q[i - 1][j];
			}
			else{
				q[i][j] = p[i][j] + min(q[i - 1][j],q[i][j - 1]);
			}
		}
	}
	for (int i = 1; i <= n; i++){
		for (int j = 1; j <= n; j++){
			cout << p[i][j] << (j < n ? " " : "\n");
		}
	}
	cout << endl;
	for (int i = 1; i <= n; i++){
		for (int j = 1; j <= n; j++){
			cout << q[i][j] << (j < n ? " " : "\n");
		}
	}
	return 0;
} 
