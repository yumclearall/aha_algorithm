#include <stdio.h>
#include <string.h>
int main()
{
	char a;
	a=getchar();
	printf("%d",a);
	return 0;
}
