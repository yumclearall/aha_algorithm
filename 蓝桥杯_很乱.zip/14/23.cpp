#include <iostream>
#include <stdio.h>
using namespace std;
bool judge(int i){
	int res = 0, k = 1;
	int j = i;
	while (i){
		res += (i % 10) * k;
		k *= 16;
		i /= 10;
	}
	
	return res % j == 0;
}
int main(){
	int i = 10;
	cout << 8+3*16+16*16*16 << "%" << 1038 << "=" << 8+3*16+16*16*16%1038;
	while(i)
		if (judge(i))
			return i;
		else 
			i++;
	return 0;
}


