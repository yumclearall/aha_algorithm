#include <stdio.h>
#include <string.h>
#include <math.h>
int main()
{
	int f=0,ch=1,m[600];
	scanf("%d",&f);
	for(int i=1;i<=f;i++)
	{
	char n[101];
	scanf("%s",n+1);
	int a[7]={0},len=strlen(n+1);	
	for(int i=1;i<=6;i++)
	{
		int j=i;
		while(j<=len)
		{
			a[i]+=(int)n[j];
			j+=6;
			}		
	}
	for(int i=1;i<=6;i++)
	{
		while(a[i]/10)
		{
			int ha=a[i],hf,sm=0,smm=0;
			while(ha/=10) smm++;
			for(int kp=0;kp<=smm;kp++)
			{
				hf=a[i]/pow(10,kp);
				sm+=hf%10;				
			}
			a[i]=sm;
		}
		m[ch]=a[i];
		ch++;
	}
}
	for(int i=1;i<=ch,f>0;i++)
	{
		printf("%d",m[i]);
		if(i%6==0&&f--) printf("\n");
	}
	getchar();getchar();
	return 0;
}
/*���룺
5
zhangfeng
wangximing
jiujingfazi
woaibeijingtiananmen
haohaoxuexi
    �������
772243
344836
297332
716652
875843*/
