#include <cstdio>
int main(){
	printf("hellow~");
	return 0;
} 
