#include <stdio.h>
int main()
{
	int n,p=10,q=90,t;
	for(n=1;n<=120;n++)
	{
		if(n%2==1) q-=p;
		if(n%4==0) q*=2;
		if(n%6==0) p*=2;
	
	}
	printf("%d",q);
	return 0;
}
