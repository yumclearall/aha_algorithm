#include<cstdio>
#include<queue>
#include<iostream>
using namespace std;
vector<vector<int> > vc(2);
//������ 
struct TreeNode {
	char val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(NULL), right(NULL) {}
    TreeNode(int x) : val(x), left(NULL), right(NULL) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
    
 };
void dfs(TreeNode* head){
	if (!head)
		return;
	//ǰ 
	printf("%c",head->val);
	dfs(head->left);
	//��		 printf("%c",head->val);
	dfs(head->right);
	//��		 printf("%c",head->val);
}
void du(TreeNode* head){
	if (!head)
		return;
	du(head->left);
	if (head->left != NULL && head->right != NULL)
		vc[1].push_back(head->val);
	else if (head->left == NULL && head->right == NULL)
		vc[0].push_back(head->val);
	du(head->right);
}
int main(){
	char s[9]= {'A','B','C','D',' ','E','F',' ','G'};
	TreeNode* head = new TreeNode(s[0]);
	queue<TreeNode*> que;
	que.push(head);
	int i = 1;
	while (i < 9){
		TreeNode* res = que.front();
		que.pop();
		if (s[i] != ' '){
			res->left = new TreeNode(s[i]);
			que.push(res->left);
		}
		i++;
		if (i < 9 && s[i] != ' '){
			res->right = new TreeNode(s[i]);
			que.push(res->right);
		}
		i++;
	}
	while(que.size())
		que.pop();
	du(head);
	cout << "��Ϊ0�Ľڵ���� = " << vc[0].size() << endl;
	cout << "�ֱ���:";
	for (int i = 0; i < vc[0].size(); i++){
		cout << " " << (char)vc[0][i];
	}
	
	cout << endl << "��Ϊ2�Ľڵ���� = " << vc[1].size() << endl;
	cout << "�ֱ��ǣ�";
	for (int i = 0; i < vc[1].size(); i++){
		cout << " " << (char)vc[1][i];
	}
	return 0;
}

