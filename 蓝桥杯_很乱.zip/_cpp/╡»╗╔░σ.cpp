#include <iostream>	//5 2 2 3 1 2
using namespace std;
int a[10],b[10],maxn = -999;
int main(){
	int n;
	cin >> n;
	for (int i = 1; i <= n; i++){
		cin >> a[i];
	}
	for (int i = n; i >= 1; i--){
		b[i] = b[i + a[i]] + 1;
		maxn = max(maxn,b[i]);
	}
	printf("%d",maxn);
	return 0;
}
