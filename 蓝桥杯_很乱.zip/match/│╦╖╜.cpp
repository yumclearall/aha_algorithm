#include <stdio.h>
int main()
{
    printf("Please enter n:");
    int n;
    scanf("%d",&n);printf("\n");
    for(int i=1;i<=n;i++) printf("%d*%d = %d\n",i,i,i*i);
    for(int i=1;i<=n;i++) printf("%d*%d*%d = %d\n",i,i,i,i*i*i);
    return 0;
    
}
