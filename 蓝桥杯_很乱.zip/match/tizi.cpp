#include <stdio.h>
#include <math.h>
int main()
{
    int find=1,x=1;
    while(find)
    {
        if (x%2=1 && x%3=2 && x%5=4 && x%6=5 && x%7=0) 
        {
            printf ("%d",x);find=0;
        }
        x+=1;
    }
    return 0;
}
