#include <stdio.h>
int main()
{
    int sum=0, n;
    do{
        printf("Input num:");
        scanf("%d",&n);sum+=n;
        printf("sum = %d\n",sum);
    }while(n!=0);
    
}
