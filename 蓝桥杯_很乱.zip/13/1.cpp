#include <stdio.h>
int a[100];
int main(){
	int n = 1478;
	int m = 0;
	while(n){
		a[m++] = n % 9;
		n = n / 9;
	}
	for (int i = 0; i < 10; i++){
		printf("%d ",a[i]);
	}
	printf("\n%d ",9 * 2 + 2 + 9 * 9 * 9 * 2);
	return 0;
} //1478
//9 * 2 + 2 + 9 * 9 * 9 * 2

