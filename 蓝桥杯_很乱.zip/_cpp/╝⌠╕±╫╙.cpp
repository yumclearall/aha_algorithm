#include <stdio.h>	//3 3 10 1 52 20 30 1 1 2 3
int a[10][10],sum = 0;
int s[1000][4];
int x[2] = {1,0};
int y[2] = {0,1};
bool flag = false;
int main(){
	int n,m,tail = 2,head = 1;
	scanf("%d%d",&n,&m);
	for (int i = 0; i < n; i++){
		for (int j = 0; j < m; j++){
			scanf("%d",&a[i][j]);
			sum += a[i][j];
		}
	}
	sum /= 2;	s[1][0] = a[0][0];	s[1][1] = 1;	s[1][2] = 0;	s[1][3] = 0; 
	int xx,yy;
	while(!flag){
		for (int i = 0; i < 2; i++){
			xx =s[head][2] + x[i];
			yy =s[head][3] + y[i];
			if (xx > n || yy > m)
				continue;
			s[tail][0] = a[xx][yy] + s[head][0];
			s[tail][1] = head + 1;
			s[tail][2] = xx;
			s[tail][3] = yy;
			if (s[tail++][0] == sum){
				flag = true;
				printf("%d\n",s[tail - 1][1] );	
			}else if (xx == n && yy == m){
				printf("-1\n");
				return 0;
			}
		}
		head++;
	}
	for(int i = 1; i < tail; i++){
		printf("%d %d %d %d\n",s[i][0],s[i][1],s[i][2],s[i][3]);
	}
	return 0;
}
