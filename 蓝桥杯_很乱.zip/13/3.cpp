#include <cstdio>
#include <iostream>
using namespace std;
int a,b;
long long n,m;
int main(){
	int s = 1,sum = 0;
	scanf("%d%d%d",&a,&b,&n);
	while(n > m){
		if(s <= 5){
			m += a;
		}else if(s <= 7){
			m += b;
		}else if(s > 7){
			s = 0;
			m += a;
		}
		s++;	sum++;
	}
	printf("%d",sum);
	return 0;
}
