#include <iostream>
using namespace std;
int sum,n,m,nn,num;
void dfs(int x,int step){
	if(step >= sum - 1){
		if(x == 1 && nn == n ){
			num++;
		}
		return;
	}
	if (step >= sum) return;
	if (x < 0)	return;
	dfs(x - 1,step + 1);
	nn++;
	dfs(x * 2,step + 1);
	nn--;
}
int main(){
	cin >> n >> m;
	sum = n + m;
	dfs(2,0);
	cout <<num <<endl;
	return 0;
}
