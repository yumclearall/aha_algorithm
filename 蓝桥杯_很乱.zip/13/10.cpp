#include <iostream>
#include <cstdio>
#include <math.h>
using namespace std;
int a[200005],b[200005],ans = 9999999;
int change(int x){
	x = sqrt(x / 2 + 1);
}
int main(){
	int n;
	scanf("%d",&n); 
	for (int i = 1; i <= n; i++){
		scanf("%d",&a[i]);
	}
	for(int i = 1; i <= n; i++){
		b[i] = i;
			for(int j = 1; j <= i; j++){
				if(a[j] > 1){
				if(change(a[j]) == a[i - 1]){
					if(b[i] > 0)b[i]--;
					}else{
					b[i]=max(b[i-1],b[i]);
				}}
				
			}
		}
		printf("%d",b[n]-1 );
		return 0;
	}
	
