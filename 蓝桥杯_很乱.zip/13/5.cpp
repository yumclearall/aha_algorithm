#include <iostream>
using namespace std;
int a[10005],b[10005];
int main(){
	int n,m;
	cin >> n;
	m = n;
	while(m--){
		for (int i = 1;i <= n; i++){
			for (int j = 1; j <= n; j++){
				a[j]++;
			}
			a[i] = 0;
			for (int k = 1;k <= n; k++){
				b[k] = max(b[k],a[k]);
			
			}
		
		}
		for (int i = n;i >= 1; i--){
			for (int j = n; j >= 1; j--){
				a[j]++;
			}
			a[i] = 0;
			for (int k = 1;k <= n; k++){
				b[k] = max(b[k],a[k]);
		
			}
	}
	}
	for (int i = 1;i <= n; i++){
		cout << b[i] << endl;
	}

}
