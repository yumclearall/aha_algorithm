#include <iostream>
#include <stdio.h>
using namespace std;
int judge(int n){
	for (int i = 2; i < n/2; i++)
		if (n % i == 0)
			return i;
	return 0;
}
int main(){
	cout << 2 << " "<<3 << " "<<337 << " ";
	cout << judge(337) ;
	
	//<< " "<< 337/judge(337);
	return 0;
}


