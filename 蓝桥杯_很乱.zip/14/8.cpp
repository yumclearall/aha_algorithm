#include <iostream>
#include <stdio.h>
#include <vector>
#include <math.h>
using namespace std;
int main(){
	int n;
	cin >> n;
	vector<int> num(n);
	for (int i = 0; i < n; i++)
		cin >> num[i];
	int res = 0, i = n -1;
	while (i > 0){
		if (num[i-1] > num[i]){
			int ch = num[i];
			num[i] = num[i-1];
			num[i-1] = ch;
			res += max(num[i], num[i-1]);
			cout << num[i]<< ' '<< num[i-1] <<endl;
			if(i+1<n)
				i++;
		}else 
			i--;
	}
	cout << res;
	return 0;
}


