#include <stdio.h>
int main()
{
	int a,b,c,d,e,f;
	for(a=0;a<10;a++)
		for(b=0;b<10;b++)
			for(c=0;c<10;c++)
				for(d=0;d<10;d++)
					for(e=0;e<10;e++)
						for(f=0;f<10;f++)
					{
						if((a*10000+b*1000+c*100+d*10+e)*f==e*10000+d*1000+c*100+b*10+a&&a!=b&&a!=c&&a!=d&&a!=e&&b!=c&&b!=d&&b!=e&&c!=d&&c!=e&&d!=e)
						printf("%d%d%d%d%d",a,b,c,d,e);
					}

	getchar();getchar();
	return 0;
}//21978
