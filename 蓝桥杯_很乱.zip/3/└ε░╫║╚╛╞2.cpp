#include <stdio.h>
struct through
{
	int p;
	int f;
	int step;
	int tour;
}a[99999999];
int main()
{
	int head=1,tail=1,sum=0;
	a[head].p=2;
	a[tail++].f=0;
	a[head].step=0;
	a[head].tour=0;
	int step;
	while(a[head].step<14)
	{
		for(int i=0;i<=1;i++)
		{
			if(a[head].p-1<0||a[head].p*2>14)
				continue;
			if(i==0)
			{
				a[tail].p=a[head].p*2;
				a[tail].f=head;
				a[tail].step=a[head].step+1;
				a[tail].tour=a[head].tour+1;
			}
			else if(i==1)
			{				
				a[tail].p=a[head].p-1;
				a[tail].f=head;
				a[tail].step=a[head].step+1;
				a[tail].tour=a[head].tour;
			}
			if(a[tail].step==13&&a[tail].tour==5&a[tail].p==2)
				sum++;
			tail++;
		}
		head++;
	}
	printf("%d",sum);
	getchar();getchar();
	return 0;
}

