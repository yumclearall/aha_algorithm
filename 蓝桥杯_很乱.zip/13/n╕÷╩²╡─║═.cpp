#include <stdio.h>
int a[20],n,k,s[20];
bool end,b[20];
void dfs(int x,int sum,int i){
	if (x == n + 1){
		if(sum == k){
			end = true;
			for(int j = 1; j <= n; j++){
				printf("%d ",s[j]);
			}	
			printf("\n");
		}
	return;
	}
	if (sum > k){
		return;
	}
	for(int i = x; i <= k; i++){
		
		if (b[i] == false){
			s[x] = a[i];
			b[i] = true;
			dfs(x + 1,sum + a[i],i + 1);
			s[x] = 0;
			b[i] = false;
		}
	}
}
int main(){
	scanf("%d%d",&n,&k);
	for(int i = 1; i <= 15; i++){
		a[i] = i;
	}
	dfs(1,0,0);
	if (end){
		printf("yes\n");
	}else{
		printf("no\n");
	}
	return 0;
} 
