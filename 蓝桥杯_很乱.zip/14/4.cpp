#include <iostream>
#include <stdio.h>
#include <math.h>
//10000 10000 1000000000 
using namespace std;
int main(){
	long a,b,c,d;
	double e;
	cin >> a >> b >> c;
	e = (double)(c- a)/b*a ;
	d = abs(e-(long)e) > 1e-5 ? 1:0;
	cout << d + (long)e;
	return 0;
}


